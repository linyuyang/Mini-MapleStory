import pygame
import constants
import random
import sprites

#Class for displaying hitpoints
class Hitpoint(object):
    def __init__(self,hitType,num):
        n = num
        #only attribute for Hitpoint, for simplicity
        self.hitImages = []
        while n>0:
            if hitType == "player":
                digit = n%10
                image = pygame.image.load("Source/number/NoRed1_%d.png" %digit).convert_alpha()
                self.hitImages.append(image)
            elif hitType == "monster":
                digit = n%10
                image = pygame.image.load("Source/number2/NoViolet1_%d.png" %digit).convert_alpha()
                self.hitImages.append(image)
            n //= 10

class Level(object):
    #super class for all levels
    def __init__(self,player,enemy_list):
        self.world_shift = 0
        self.level_limit = -1000
        self.platform_list = None
        self.ropes_list = None
        self.enemy_list = enemy_list
        self.platform_list = pygame.sprite.Group()
        self.wall_list = pygame.sprite.Group()
        self.enemy_list = pygame.sprite.Group()
        self.player = player
        self.background = None
        self.hitDraw = []
    def checkCollision(self, obj1 , obj2):
        Rect1 = obj1.rect
        Rect2 = obj2.rect
        return not (
            (Rect1.top > Rect2.bottom) or
            (Rect1.left > Rect2.right) or (Rect1.right < Rect2.left) 
                    ) and abs(Rect1.bottom - Rect2.top) < 15
    def checkMultipleCollision(self, obj, objList):
        for element in objList:
            if self.checkCollision(obj,element):
                return [True,element]
        return [False]
    #Check collision between player and platforms
    def checkOnGround(self):
        if self.checkMultipleCollision(self.player,self.platform_list.sprites())[0]:
            self.player.rect.bottom = self.checkMultipleCollision(self.player,self.platform_list.sprites())[1].rect.top
            self.player.onGround = True
            self.player.state = "resting"
        else:
            self.player.onGround = False
        
        for monster in self.enemy_list.sprites():
            if self.checkMultipleCollision(monster,self.platform_list.sprites())[0]:
                monster.rect.bottom = self.checkMultipleCollision(monster,self.platform_list.sprites())[1].rect.top
                monster.onGround = True
            else:
                monster.onGround = False

#Try to add rope feature, fail...
    def checkCollisionWall(self, obj1 , obj2):
        Rect1 = obj1.rect
        Rect2 = obj2.rect
        return not (
            (Rect1.bottom < Rect2.top) or (Rect1.top > Rect2.bottom) or
            (Rect1.left > Rect2.right) or (Rect1.right < Rect2.left) 
                    )

    def calDx(self, obj1, obj2):
        Rect1 = obj1.rect
        Rect2 = obj2.rect
        #Monster.dx_left and Monster.dx_right
        return (Rect1.left-Rect2.right, Rect2.left-Rect1.right)
    def checkCollsionWithMonster(self):
        for enemy in self.enemy_list.sprites():
            enemy.dx_left = self.calDx(self.player,enemy)[0]
            enemy.dx_right = self.calDx(self.player,enemy)[1]
            if self.player.attacking and (self.player.ani.currentFrameNum == 
                self.player.ani.numFrames - 2) and enemy.hurtFinish and not self.player.attackFinish and self.player.direction == "L" and enemy.dx_left > -40 and enemy.dx_left < 50:
                # #Draw hit num in draw()
                enemy.hurt = True
                self.popAttack = self.player.hitpoint + random.randint(-20,30)
                enemy.hp -= self.popAttack
                self.hitDraw = []
                hit1 = Hitpoint("player",self.popAttack)
                self.hitDraw.append([hit1.hitImages,enemy])
                enemy.rect.x += -2
                if enemy.direction == "L":
                    enemy.ani = enemy.hitAnim_left
                elif enemy.direction == "R":
                    enemy.ani = enemy.hitAnim_right
                enemy.hurtFinish = False
                pygame.mixer.music.load("hit.ogg")
                pygame.mixer.music.play()
            if self.player.attacking and (self.player.ani.currentFrameNum == 
                self.player.ani.numFrames - 2) and enemy.hurtFinish and self.player.direction == "R" and enemy.dx_right > -40 and enemy.dx_right < 50:
                enemy.hurt = True
                self.popAttack = self.player.hitpoint + random.randint(-20,30)
                enemy.hp -= self.popAttack
                self.hitDraw = []
                # #Draw hit num in draw()
                hit2 = Hitpoint("player",self.popAttack)
                self.hitDraw.append([hit2.hitImages,enemy])
                enemy.rect.x += 2
                if enemy.direction == "L":
                    enemy.ani = enemy.hitAnim_left
                elif enemy.direction == "R":
                    enemy.ani = enemy.hitAnim_right
                enemy.hurtFinish = False
                pygame.mixer.music.load("hit.ogg")
                pygame.mixer.music.play()
            if pygame.sprite.collide_rect(enemy,self.player) and self.player.hurtFinish:
                popAttack = enemy.hitpoint + random.randint(-20,10)
                hit3 = Hitpoint("monster",popAttack)
                self.player.hp -= popAttack
                self.hitDraw.append([hit3.hitImages,self.player])
                self.player.hurtFinish = False
            else:
                self.player.attackedAndBy = (False,None)



    def update(self,screen):
        self.player.gravity()
        self.checkOnGround()
        self.checkCollsionWithMonster()
    #Draw everything on this level
    def draw(self, screen):
        # screen.fill(constants.WHITE)
        image = pygame.image.load("bg.png")
        bg = pygame.transform.scale(image,(1024,constants.SCREEN_HEIGHT))
        screen.blit(bg,[0,0])
        screen.blit(self.background, self.pos)
        # self.platform_list.draw(screen)
        for hitPerMonster in self.hitDraw:
            offset = 0
            for singleDigit in hitPerMonster[0]:
                screen.blit(singleDigit,(hitPerMonster[1].rect.x-5+offset,hitPerMonster[1].rect.y-50))
                offset += 35
    def shift_world(self, shift_x):
        self.world_shift += shift_x
        self.pos[0] += shift_x
        for platform in self.platform_list.sprites():
            platform.rect.x += shift_x
        for enemy in self.enemy_list.sprites():
            enemy.rect.x += shift_x
        self.entrance.rect.x += shift_x
        self.exit.rect.x += shift_x

class Map_1(Level):
    def __init__(self,player,enemy_list):
        Level.__init__(self,player,enemy_list)
        self.background = pygame.image.load("MapleMap.png").convert_alpha()
        self.pos = [0,-300]
        self.enemy_list = enemy_list
        #List of all platform in this map
        self.level = [[(490,30),290,580]
                ]
        for platform in self.level:
            block = pygame.sprite.Sprite()
            block.image = pygame.Surface(platform[0])
            block.rect = block.image.get_rect()
            block.rect.x = platform[1]
            block.rect.y = platform[2]
            self.platform_list.add(block)
        self.entrance = sprites.Portal(310,445)
        self.exit = sprites.Portal(650,445)

        self.entrance.ani.play()
        self.exit.ani.play()
    def __str__(self):
        return "Map1"

class Map_2(Level):
    def __init__(self,player,enemy_list):
        Level.__init__(self,player,enemy_list)
        self.background = pygame.image.load("MapleMap2.png").convert_alpha()
        self.enemy_list = enemy_list
        self.pos = [-150,-145]
        #List of all platform in this map
        self.level = [[(1600,30),0,565]
                ]

        for platform in self.level:
            block = pygame.sprite.Sprite()
            block.image = pygame.Surface(platform[0])
            block.rect = block.image.get_rect()
            block.rect.x = platform[1]
            block.rect.y = platform[2]
            self.platform_list.add(block)
            self.entrance = sprites.Portal(80,430)
            self.exit = sprites.Portal(1500,430)
            self.entrance.ani.play()
            self.exit.ani.play()
    def __str__(self):
        return "Map2"
class Map_3(Level):
    def __init__(self,player,enemy_list):
        Level.__init__(self,player,enemy_list)
        self.background = pygame.image.load("MapleMap_boss.png").convert_alpha()
        self.enemy_list = enemy_list
        self.pos = [0,-49]
        #List of all platform in this map
        self.level = [[(1600,30),0,560]
                ]

        for platform in self.level:
            block = pygame.sprite.Sprite()
            block.image = pygame.Surface(platform[0])
            block.rect = block.image.get_rect()
            block.rect.x = platform[1]
            block.rect.y = platform[2]
            self.platform_list.add(block)
        self.entrance = sprites.Portal(80,430)
        self.exit = sprites.Portal(1500,430)
        self.entrance.ani.play()
        self.exit.ani.play()
    def __str__(self):
        return "Map3"
