#Framework code from Program Arcade Games With Python And Pygame, by Paul Vincent Craven
#Code without citation are all written by Yuyang Lin
import pygame
import sys
import constants
import sprites
import level
import random
 
pygame.init()
FPS = 120
clock = pygame.time.Clock()
FLAG = pygame.FULLSCREEN|pygame.HWSURFACE
screen=pygame.display.set_mode((constants.SCREEN_WIDTH, constants.SCREEN_HEIGHT),
                                FLAG
                               )
#screen = pygame.display.set_mode((constants.SCREEN_WIDTH, constants.SCREEN_HEIGHT))
pygame.display.set_caption("Maple Story")
#Splash screen
def splash():
    intro = True
    goHelper = False
    pygame.mixer.init()
    pygame.mixer.music.load("Maplestory.ogg")
    pygame.mixer.music.play(-1)
    while intro:
        screen.fill(constants.BLACK)
        splash_bg = pygame.image.load("splash_bg.jpg")
        splash_image = pygame.image.load("splash_image.png").convert_alpha()
        splash_image_pos = (40,40)
        screen.blit(splash_bg,(0,0))
        screen.blit(splash_image,splash_image_pos)

        font1 = pygame.font.SysFont("comicsansms", 40, True, False)
        font2 = pygame.font.SysFont("comicsansms", 25, True, False)
        font3 = pygame.font.SysFont("comicsansms", 20, False, False)

        title = font1.render("Mini Maplestory", True, constants.RED)
        title_pos = (690,100)
        subtitle = font2.render("15-112 Term Project", True, constants.RED)
        subtitle_pos = (710,150)
        name = font3.render("By Yuyang Lin",True, constants.TEAL)
        name_pos = (850,580)
        bottome1 = pygame.draw.rect(screen,constants.BLACK,(745,240,200,80),1) 
        playgame = font2.render("PLAY GAME", True, constants.NAVY)
        playgame_pos = (775,260)
        screen.blit(playgame,(775,260))       
        
        bottome2 = pygame.draw.rect(screen,constants.BLACK,(745,350,200,80),1) 
        helper = font2.render("HELP", True, constants.NAVY)
        helper_pos = (813,372)
        screen.blit(helper,(813,372))
        
        bottome3 = pygame.draw.rect(screen,constants.BLACK,(745,460,200,80),1) 
        exitgame = font2.render("EXIT", True, constants.NAVY)
        exitgame_pos = (813,480)
        screen.blit(exitgame,(813,480))
        screen.blit(title,title_pos)
        screen.blit(subtitle,subtitle_pos)
        screen.blit(name,name_pos)
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    intro = False
                elif event.key == pygame.K_SPACE:
                    helper()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x = pygame.mouse.get_pos()[0]
                y = pygame.mouse.get_pos()[1]
                if not (x<745 or x>945 or y<240 or y>320):
                    playgame = font2.render("PLAY GAME", True, constants.TEAL)
                    screen.blit(playgame,playgame_pos)
                    intro = False
                    goHelper = False
                    pygame.mixer.music.stop()
                    game()
                elif not (x<745 or x>945 or y<350 or y>430):
                    # helper = font2.render("HELP", True, constants.TEAL)
                    # screen.blit(helper,helper_pos)
                    intro = False
                    goHelper = True
                elif not (x<745 or x>945 or y<460 or y>540):
                    exitgame = font2.render("EXIT", True, constants.TEAL)
                    screen.blit(exitgame,exitgame_pos)
                    pygame.quit()
                    sys.exit()
        pygame.display.update()
        
    while helper:
        splash_bg = pygame.image.load("splash_bg.jpg")
        screen.blit(splash_bg,(0,0))
        font1 = pygame.font.SysFont("comicsansms", 40, True, False)
        font2 = pygame.font.SysFont("comicsansms", 30, True, False)
        title = font1.render("Game Help",True, constants.AQUA)
        screen.blit(title,(400,10))
        helper1 = font2.render("- Press left and right arrow to move player",
                                True, constants.AQUA)
        helper2 = font2.render("- Press key A to attack", True, constants.AQUA)
        helper3 = font2.render("- Press key S to jump", True, constants.AQUA)
        helper4=font2.render("- Press key Q to use recover skill, recover 200HP"
                            ,True,constants.AQUA)
        helper5text = "- Press key SPACE to use fireball skill, consume 100MP"
        helper5=font2.render(helper5text,True,constants.AQUA)
        helper6= font2.render("- Whenever player kills a monster, player's MP"
                            ,True, constants.AQUA)
        helper7 = font2.render("increases by 100, whenever player kills a boss"
                            ,True, constants.AQUA)
        helper8 = font2.render("player's MP increases by 500"
                            ,True,constants.AQUA)
        screen.blit(helper1,(100,100))
        screen.blit(helper2,(100,160))
        screen.blit(helper3,(100,220))
        screen.blit(helper4,(100,280))
        screen.blit(helper5,(100,340))
        screen.blit(helper6,(100,400))
        screen.blit(helper7,(100,460))
        screen.blit(helper8,(100,520))
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    helper = False
                    splash()
    
        pygame.display.update()
        
    pygame.display.flip()
    pygame.mixer.music.stop()
# #Pause splash screen
def paused():
    pause = True
    font1 = pygame.font.SysFont("comicsansms", 60, True, False)
    font2 = pygame.font.SysFont("comicsansms", 30, True, False)
    font3 = pygame.font.SysFont("comicsansms", 20, False, False)
    pause1_pos = (300,200)
    pausetext1 = font1.render("GAME PAUSED", True, constants.TEAL)
    pausetext2 = font2.render("Press ESC to resume", True, constants.TEAL)
    pause2_pos = (360,280)
    screen.blit(pausetext1,pause1_pos)
    screen.blit(pausetext2,pause2_pos)
    while pause:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause = False

        pygame.display.update()
        clock.tick(15) 
def confirm_exit():
    confirm = True
    font1 = pygame.font.SysFont("comicsansms", 60, True, False)
    font2 = pygame.font.SysFont("comicsansms", 30, True, False)
    font3 = pygame.font.SysFont("comicsansms", 20, False, False)
    confirm_pos = (300,200)
    confirmtext = font2.render("Confirm To EXIT? Press ECS", True, constants.TEAL)
    screen.blit(confirmtext,confirm_pos)
    while confirm:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    confirm = False
                    pygame.quit()
                    sys.exit()
        pygame.display.update()
        clock.tick(15)
#Game over splash screen
def gameover():
    over = True
    font1 = pygame.font.SysFont("comicsansms", 60, True, False)
    font2 = pygame.font.SysFont("comicsansms", 30, True, False)
    font3 = pygame.font.SysFont("comicsansms", 20, False, False)
    over_pos = (300,200)
    overtext1 = font1.render("GAME OVER", True, constants.TEAL)
    pausetext2 = font2.render("Press ESC To Return Main Menu", True, constants.TEAL)
    pause2_pos = (320,280)
    screen.blit(overtext1,over_pos)
    screen.blit(pausetext2,pause2_pos)
    while over:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause = False
                    splash()
        pygame.display.update()
        clock.tick(15)
def gamefinish():
    over = True
    font1 = pygame.font.SysFont("comicsansms", 60, True, False)
    font2 = pygame.font.SysFont("comicsansms", 30, True, False)
    font3 = pygame.font.SysFont("comicsansms", 20, False, False)
    over1_pos = (240,200)
    over2_pos = (300,260)
    overtext1 = font1.render("YOU'VE COMPLETED", True, constants.TEAL)
    overtext2 = font1.render(" THE GAME!!",True,constants.TEAL)
    pausetext2 = font2.render("Press ESC To Return Main Menu", True, constants.TEAL)
    pause2_pos = (280,350)
    screen.blit(overtext1,over1_pos)
    screen.blit(overtext2,over2_pos)
    screen.blit(pausetext2,pause2_pos)
    while over:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause = False
                    splash()
        pygame.display.update()
        clock.tick(15)
#------MAIN PROGRAM------
def game():
    pygame.time.set_timer(pygame.USEREVENT+1,3000)
    pygame.time.set_timer(pygame.USEREVENT+2,2000)
    pygame.time.set_timer(pygame.USEREVENT+3,100)
    pygame.time.set_timer(pygame.USEREVENT+4,500)
    pygame.time.set_timer(pygame.USEREVENT+5,200)
    pygame.time.set_timer(pygame.USEREVENT+6,8000)
    playtime = 0
    pygame.mixer.init()
    # bgm = pygame.mixer.Sound("Hall Of Time.ogg")
    bgm = pygame.mixer.Sound("Hall of Time.ogg")

    recover = pygame.mixer.Sound("skill_recover.ogg")
    skill_big = pygame.mixer.Sound("skill_big.ogg")
    potion = pygame.mixer.Sound("recover.ogg")

    #pygame.mixer.music.set_endevent(pygame.constants.USEREVENT)
    bgm.play(-1,0,2)

    #Create the player
    player1 = sprites.Player("player4")
    active_sprite_list = pygame.sprite.Group()
    active_sprite_list.add(player1)
    monster1 = sprites.Monster(clock.get_time()/1000.0,"GreenMushroom")
    monster2 = sprites.Monster(clock.get_time()/1000.0,"HornMushroom")
    boss1  = sprites.Boss1(clock.get_time()/1000.0,"boss")
    boss2 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
    active_enemy_list = pygame.sprite.Group()
    active_enemy_list.add(monster1)
    active_enemy_list.add(monster2)
    active_enemy_list.add(boss1)
    active_enemy_list.add(boss2)
    fireball_list = pygame.sprite.Group()
    level1 = level.Map_1(player1, active_enemy_list)
    scrolled = 0
    playing = True
    #--------Main Program Loop--------
    while playing:
        if player1.hp <= 0:
            playing = False
            gameover()
        milliseconds = clock.get_time()
        seconds = milliseconds / 1000.0 
        playtime += seconds
        #------Main Event Loop------
        for event in pygame.event.get():
            if event.type ==  pygame.QUIT:
                playing = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and not player1.attacking:
                    player1.go_left()
                if event.key == pygame.K_RIGHT and not player1.attacking:
                    player1.go_right()  
                if event.key == pygame.K_s:
                    if player1.state != "jumping" and player1.onGround == True:
                        player1.jump()
                        pygame.mixer.music.load("jump.ogg")
                        pygame.mixer.music.play()
                if event.key == pygame.K_ESCAPE:
                    playing = False #quit game in fullscreen
                    confirm = True
                    confirm_exit()

                if event.key == pygame.K_a:
                    player1.attacking = True
                    player1.attack()
                    pygame.mixer.music.load("attack.ogg")
                    pygame.mixer.music.play()
                if event.key == pygame.K_r:
                    player1.rect.x = 300
                    player1.rect.y = 400
                    player1.change_y = 0
                #Using health restoring skill to restore hp by 100
                if event.key == pygame.K_q and not player1.cooling_q and (
                player1.mp >= 100):
                    player1.recoverConductor.play()
                    recover.play()
                    player1.mp -= 100
                    player1.hp += 200
                    player1.cooling_q = True
                    potion.play()
                #Pause game pressing P
                if event.key == pygame.K_p:
                    pause = True
                    paused()
                if event.key == pygame.K_m:
                    intro = True
                    bgm.stop()
                    splash()
                #Use fireball skill pressing SPACE and 100 mp is consumed
                if event.key == pygame.K_SPACE and player1.mp >= 100:
                    player1.mp -= 100
                    player1.skillAttacking = True
                    player1.ani = player1.attackingAnim_right_1
                    player1.attackingAnim_right_1.play()
                    player1.fireballAnim_ball.play()
                    fireball_list.add(sprites.Fireball(player1.fireballAnim_ball,player1))
                    player1.fireballAnim_fire.blit(screen,(player1.rect.x,player1.rect.y))
                #Enter another map by pressing UP
                if event.key == pygame.K_UP:
                    if pygame.Rect.colliderect(player1.rect,level1.exit.rect):
                        print("entering map...")
                        if (level1.__str__() == "Map1"):
                            active_enemy_list.empty()
                            level1 = level.Map_2(player1,active_enemy_list)
                            boss2 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
                            active_enemy_list.add(boss2)
                            player1.rect.y = 400
                            player1.rect.centerx = level1.entrance.rect.centerx
                        elif level1.__str__() == "Map2":
                            active_enemy_list.empty()
                            level1 = level.Map_3(player1,active_enemy_list)
                            boss1 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
                            active_enemy_list.add(boss1)
                            boss2 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
                            active_enemy_list.add(boss2)
                            player1.rect.y = 400
                            player1.rect.centerx = level1.entrance.rect.centerx
                        elif level1.__str__() == "Map3":
                            gamefinish()
                            # active_enemy_list.empty()
                            # level1 = level.Map_3(player1,active_enemy_list)
                            # boss1 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
                            # active_enemy_list.add(boss1)
                            # boss2 = sprites.Boss2(clock.get_time()/1000.0,"boss2")
                            # active_enemy_list.add(boss2)
                            # player1.rect.y = 400
                            # player1.rect.centerx = level1.entrance.rect.centerx
                    else:
                        print(level1.entrance.rect)
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT and player1.change_x < 0:
                    player1.stop()
                if event.key == pygame.K_RIGHT and player1.change_x > 0:
                    player1.stop()
                if event.key == pygame.K_a:
                    player1.state = "still"
                    player1.attacking = False
            #Automove for monster every 4 seconds
            if event.type == pygame.USEREVENT+1:
                for monster in active_enemy_list.sprites():
                    if not monster.hurt:
                        monster.autoMove()
            #Reset monster every 0.1 second
            if event.type == pygame.USEREVENT+3:
                for monster in active_enemy_list.sprites():
                    if monster.hurt:
                        monster.reset()
            #player gets hurt every 2 seconds if collide with monster
            if event.type == pygame.USEREVENT+2:
                if not player1.hurtFinish:
                    player1.hurtFinish = True
                for monster in active_enemy_list.sprites():
                    if monster.dead:
                        hitmusic = pygame.mixer.Sound("mushroomDie.ogg")
                        hitmusic.play()
                        monster.kill()
                        player1.mp += 100
                        if monster.__str__() == "Boss":
                            player1.mp += 500
                            potion
            #Refresh hit points
            if event.type == pygame.USEREVENT+4:
                level1.hitDraw = []
            #Reset hurt monsters    
            if event.type == pygame.USEREVENT+5:
                for monster in active_enemy_list.sprites():
                    if not monster.hurtFinish:
                        monster.hurtFinish = True
            #Spawn monsters every 8 seconds if number of monsters < 8
            if event.type == pygame.USEREVENT+6:
                if len(active_enemy_list) < 10:
                    horn = sprites.HornMushroom(playtime)
                    green = sprites.GreenMushroom(playtime)
                    horn.rect.x = random.randrange(level1.level[0][1],level1.level[0][1]+level1.level[0][0][0])
                    green.rect.x = random.randrange(level1.level[0][1],level1.level[0][1]+level1.level[0][0][0])
                    active_enemy_list.add(horn)
                    active_enemy_list.add(green)
                if player1.cooling_q:
                    player1.cooling_q = False

        #Scrolling map
        if player1.rect.right > constants.SCREEN_WIDTH * 0.6:
            diff =  (constants.SCREEN_WIDTH * 0.6) - player1.rect.right
            if abs(level1.world_shift) < 628:
                player1.rect.right = constants.SCREEN_WIDTH * 0.6
                level1.shift_world(diff)
        elif player1.rect.right < constants.SCREEN_WIDTH * 0.3:
            diff = player1.rect.right - (constants.SCREEN_WIDTH * 0.3)
            if level1.world_shift < -1.8:
                player1.rect.right = constants.SCREEN_WIDTH * 0.3 + 1
                level1.shift_world(-1*diff)
        #Clear the screen
        screen.fill(constants.BLACK)
        player1.update(screen)
        level1.update(screen)
        active_enemy_list.update(screen)

        level1.draw(screen)
        #Draw fireballs and update their attack effects
        fireball_list.update()
        for fireball in fireball_list.sprites():
            fireball.update()
            fireball.ani.blit(screen,(fireball.rect))
        fire_hit_dict = pygame.sprite.groupcollide(fireball_list,active_enemy_list,True,False)
        for hit_ball in fire_hit_dict:
            skill_big.play()
            for monster in fire_hit_dict[hit_ball]:
                player1.fireballAnim_fire.play()
                player1.fireballAnim_fire.blit(screen,(monster.rect.centerx-100,monster.rect.centery-160))
                monster.hp -= 180


        #Draw all monsters
        for monster in active_enemy_list.sprites():
            monster.ani.blit(screen,(monster.rect.x,monster.rect.y))
        # monster1.ani.blit(screen, (monster1.rect.x,monster1.rect.y))
        # monster2.ani.blit(screen,(monster2.rect.x,monster2.rect.y))
        

        player1.recoverAnim_effect.blit(screen,(player1.rect.x-95,player1.rect.y-300))
        player1.ani.blit(screen, (player1.rect.x,player1.rect.y))
        player1.recoverAnim_affected.blit(screen,(player1.rect.x-85,player1.rect.y-95))
        level1.entrance.ani.blit(screen,(level1.entrance.rect.x,level1.entrance.rect.y))
        level1.exit.ani.blit(screen,(level1.exit.rect.x,level1.exit.rect.y))

        #user interface
        # pygame.draw.rect(screen,constants.BLACK,(0,0,1024,60),0)
        font = pygame.font.SysFont("comicsansms", 25, True, False)
        HP = font.render("HP", True, constants.RED)
        MP = font.render("MP", True, constants.BLUE)
        screen.blit(HP,[50,12])
        pygame.draw.rect(screen,constants.RED,(120,26,300*(player1.hp/2000),10),0)
        pygame.draw.rect(screen,constants.BLUE,(520,26,300*(player1.mp/1000),10),0)
        screen.blit(MP,[450,12])
        menu = font.render("IN GAME", True, constants.BLACK)
        screen.blit(menu,[880,20])
        pygame.display.flip()
        clock.tick(FPS)
        


splash()
game()
    
pygame.quit()
