{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;\f1\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red38\green38\blue38;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sl400

\f0\fs28 \cf2 \expnd0\expndtw0\kerning0
Readme.txt\
\pard\pardeftab720\sl320

\fs24 \cf0 \expnd0\expndtw0\kerning0
\
\pard\pardeftab720\sl320\sa321

\b\fs48 \cf0 \expnd0\expndtw0\kerning0
Mini Maplestory\
\pard\pardeftab720\sl320\sa240

\b0\fs24 \cf0 \expnd0\expndtw0\kerning0
(c) Yuyang Lin\
\pard\pardeftab720\sl320\sa280

\b\fs28 \cf0 \expnd0\expndtw0\kerning0
This game is a small version of popular MMPRG MapleStory, written in Python with Pygame module. Player\'92s goal is to travel between maps to kill monster and monster-boss. The game includes a large amount of animations. In other to implement animations easily and conveniently, I import Pyganim written by Albert Sweigart.\'a0\
\pard\pardeftab720\sl320\sa120

\b0\fs24 \cf0 \expnd0\expndtw0\kerning0
\
\pard\pardeftab720\sl320\sa240
\cf0 \expnd0\expndtw0\kerning0
Requirements:\
\pard\tx220\tx720\pardeftab720\li720\fi-720\sl320
\ls1\ilvl0\cf0 \kerning1\expnd0\expndtw0 {\listtext	\'95	}\expnd0\expndtw0\kerning0
Pygame\
\ls1\ilvl0\kerning1\expnd0\expndtw0 {\listtext	\'95	}\expnd0\expndtw0\kerning0
Python 3\
\ls1\ilvl0\kerning1\expnd0\expndtw0 {\listtext	\'95	}\expnd0\expndtw0\kerning0
Pyganim\
\pard\pardeftab720\sl320\sa240
\cf0 \expnd0\expndtw0\kerning0
How to run:\
\pard\pardeftab720\sl320

\f1 \cf0 \expnd0\expndtw0\kerning0
Download all the files in the zip file, run main.py to run the program\
}