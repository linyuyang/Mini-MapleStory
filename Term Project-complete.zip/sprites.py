import  pygame
from pygame.locals import *
import pyganim
import sys
import constants
import level
import random
import copy

class Player(pygame.sprite.Sprite):
    
    def __init__(self, characterClass):
        super(Player, self).__init__()
        # Set speed vector of player
        self.hp = 2000
        self.mp = 1000
        self.state = "still"
        self.change_x = 0
        self.change_y = 0
        self.acceleration = 0
        self.counter = 0
        self.index = 0
        self.onGround = False
        self.attacking = False
        self.attackmode = 0
        self.hitpoint = 60
        #Animation for player's movement
        self.standing_left = []
        self.standing_right = []
        for i in range(5):
            image = pygame.image.load("Source/%s/stand1_%d.png" % (characterClass,i)).convert_alpha()
            self.standing_left.append((image,0.38))
            self.standing_right.append((pygame.transform.flip(image,True,False),0.38))
        #All standing animation
        self.standingAnim_left = pyganim.PygAnimation(self.standing_left)
        self.standingAnim_right = pyganim.PygAnimation(self.standing_right)      
        self.walking_left = []
        self.walking_right = []
        for i in range(4):
            image = pygame.image.load("Source/%s/walk1_%d.png" % (characterClass, i)).convert_alpha()
            self.walking_left.append((image,0.18))
            self.walking_right.append((pygame.transform.flip(image,True,False),0.18))
        #All walking animation 
        self.walkingAnim_left = pyganim.PygAnimation(self.walking_left)
        self.walkingAnim_right = pyganim.PygAnimation(self.walking_right)        
        #Animation for attacking
        self.attacking_left_1 = []
        self.attacking_right_1 = []
        for i in range(3):
            image = pygame.image.load("Source/%s/swingO1_%d.png" % (characterClass, i)).convert_alpha()
            self.attacking_left_1.append((image,0.18))
            self.attacking_right_1.append((pygame.transform.flip(image,True,False),0.18))

        self.attacking_left_3 = []
        self.attacking_right_3 = []
        for i in range(3):
            image = pygame.image.load("Source/%s/swingO3_%d.png" % (characterClass, i)).convert_alpha()
            self.attacking_left_3.append((image,0.18))
            self.attacking_right_3.append((pygame.transform.flip(image,True,False),0.18))
        
        self.attacking_left_4 = []
        self.attacking_right_4 = []
        for i in range(3):
            image = pygame.image.load("Source/%s/swingOF_%d.png" % (characterClass, i)).convert_alpha()
            self.attacking_left_4.append((image, 0.18))
            self.attacking_right_4.append((pygame.transform.flip(image,True,False),0.18))
        self.attacking_left_2 = []
        self.attacking_right_2 = []
        for i in range(3):
            image = pygame.image.load("Source/%s/swingO1_%d.png" % (characterClass, i)).convert_alpha()
            self.attacking_left_2.append((image, 0.2))
            self.attacking_right_2.append((pygame.transform.flip(image,True,False),0.2))    
        #Animations for skills
        self.skill_recover_affected = []
        self.skill_recover_effect = []
        for i in range(14):
            image = pygame.image.load("Source/skill/affected_%d.png" % i).convert_alpha()
            self.skill_recover_affected.append((image,0.06))
        for i in range(22):
            image = pygame.image.load("Source/skill/effect_%d.png" % i).convert_alpha()
            self.skill_recover_effect.append((image,0.06))
        #key q: Heal: Summons the Holy Spirit to recover player's HP by 60%
        self.recoverAnim_affected = pyganim.PygAnimation(self.skill_recover_affected,False)
        self.recoverAnim_effect = pyganim.PygAnimation(self.skill_recover_effect,False)
        self.cooling_q = False
        self.recoverConductor = pyganim.PygConductor([self.recoverAnim_affected,self.recoverAnim_effect])
        #key space: fireball
        self.skill_fireball_ball = []
        self.skill_fireball_hit = []
        for i in range(3):
            image = pygame.image.load("Source/ball/ball_%d.png" % i).convert_alpha()
            self.skill_fireball_ball.append((image,0.12))
        for i in range(7):
            image = pygame.image.load("Source/ball/hit.0_%d.png" % i).convert_alpha()
            self.skill_fireball_hit.append((image,0.1))
        self.fireballAnim_ball = pyganim.PygAnimation(self.skill_fireball_ball,True)
        self.fireballAnim_fire = pyganim.PygAnimation(self.skill_fireball_hit,False)
        self.fireballConductor = pyganim.PygConductor([self.fireballAnim_ball,self.fireballAnim_fire])

        #All attacking animation
        self.attackingAnim_left_1 = pyganim.PygAnimation(self.attacking_left_1)
        self.attackingAnim_right_1 = pyganim.PygAnimation(self.attacking_right_1)
        self.attackingAnim_left_3 = pyganim.PygAnimation(self.attacking_left_3)
        self.attackingAnim_right_3 = pyganim.PygAnimation(self.attacking_right_3)
        self.attackingAnim_left_4 = pyganim.PygAnimation(self.attacking_left_4)
        self.attackingAnim_right_4 = pyganim.PygAnimation(self.attacking_right_4)
        self.attackingAnim_left_2 = pyganim.PygAnimation(self.attacking_left_2)
        self.attackingAnim_right_2 = pyganim.PygAnimation(self.attacking_right_2)

        self.jump_left = pygame.image.load("Source/%s/jump_0.png"% characterClass)
        self.jumpAnim_left = pyganim.PygAnimation([(self.jump_left,0.5)])
        self.jump_right = pygame.transform.flip(self.jump_left,True,False)
        self.jumpAnim_right = pyganim.PygAnimation([(self.jump_right,0.5)])
        self.climbingAnim = pyganim.PygAnimation([(pygame.image.load("Source/%s/rope_0.png" % characterClass),0.25),
                                                  (pygame.image.load("Source/%s/rope_1.png" % characterClass),0.25)
                                                ])

        self.ani = self.jumpAnim_right
        self.image = self.ani.getCurrentFrame()
        self.direction = "R"
        # Set a reference to the image rect
        self.rect = self.ani.getRect()
        self.rect.x = 300
        self.rect.bottom = 500
        self.attacked = False
        self.attackFinish = False
        self.hurtFinish = True
        self.skillAttacking = False

        self.ani.play()
        
    
    def update(self,screen):
        self.gravity()  
        self.counter += 1
        self.rect.x += self.change_x
        self.rect.y += self.change_y
        if self.skillAttacking:
            if self.ani.currentFrameNum == self.ani.numFrames - 1:
                self.skillAttacking = False
        #animation for walking, standing
        if not self.attacking and not self.skillAttacking:
            if self.direction == "L" and self.change_x != 0 :
                self.ani = self.walkingAnim_left
            elif self.direction == "L" and (self.change_x == 0 or self.state == "resting"):
                self.ani = self.standingAnim_left
            if self.direction == "R" and self.change_x != 0:
                self.ani = self.walkingAnim_right
            elif self.direction == "R" and (self.change_x == 0 or self.state == "resting"):
                self.ani = self.standingAnim_right
            #animation for jumping
            if  self.direction == "L" and self.state == "jumping":
                self.ani = self.jumpAnim_left
            elif self.direction == "R" and self.state == "jumping":
                self.ani = self.jumpAnim_right
            
        #attacking
        
        if self.onGround == True:
            self.change_y = 0
        elif self.onGround == False:
            if self.direction == "L":   self.ani = self.jumpAnim_left
            elif self.direction == "R": self.ani = self.jumpAnim_right
        
        self.ani.play()
    # Player-controlled movement:
    def go_left(self):
        self.change_x = -5
        self.direction = "L"

    def go_right(self):
        self.change_x = 5
        self.direction = "R"
 
    def stop(self):
        self.change_x = 0
        self.state = "still"
    def jump(self):
        self.state = "jumping"
        self.change_y = -25
        self.onGround = False
    def climb(self):
        if self.onRope:
            self.ani = self.climbingAnim

    #Effect of gravity
    def gravity(self):
        if self.onGround == False:
            self.change_y += 1.6
            if self.direction == "L": 
                self.ani = self.jumpAnim_left
            elif self.direction == "R": 
                self.ani = self.jumpAnim_right
        else:
            self.change_y = 0
    def takeDamage(self, hurtpoint):
        self.hp -= hurtpoint

    def attack(self):
        self.attackmode = random.choice([1,2,4,3])
        if self.attacking and self.direction == "L":
            if self.attackmode == 1:
                self.ani = self.attackingAnim_left_1
            elif self.attackmode == 2:
                self.ani = self.attackingAnim_left_2
            elif self.attackmode == 3:
                self.ani = self.attackingAnim_left_3
            elif self.attackmode == 4:
                self.ani = self.attackingAnim_left_4
        elif self.attacking and self.direction == "R":
            if self.attackmode == 1:
                self.ani = self.attackingAnim_right_1
            elif self.attackmode == 2:
                self.ani = self.attackingAnim_right_2
            elif self.attackmode == 3:
                self.ani = self.attackingAnim_right_3
            elif self.attackmode == 4:
                self.ani = self.attackingAnim_right_4

class Monster(pygame.sprite.Sprite):
    def __init__(self,startTime,monsterType):
        super(Monster, self).__init__()
        
        #Animation for standing
        self.standing_left = []
        self.standing_right = []
        for i in range(3):
            image = pygame.image.load("Source/%s/stand_%d.png" % (monsterType,i)).convert_alpha()
            self.standing_left.append((image,0.18))
            self.standing_right.append((pygame.transform.flip(image,True,False),0.18))
        #Animation for walking
        self.walking_left = []
        self.walking_right = []
        for i in range(4):
            image = pygame.image.load("Source/%s/move_%d.png" % (monsterType, i)).convert_alpha()
            self.walking_left.append((image,0.16))
            self.walking_right.append((pygame.transform.flip(image,True,False),0.16))
        #Animation for dying
        self.die_left = []
        self.die_right = []
        for i in range(4):
            image = pygame.image.load("Source/%s/die1_%d.png" % (monsterType, i)).convert_alpha()
            self.die_left.append((image,0.3))
            self.die_right.append((pygame.transform.flip(image,True,False),0.3))
        
        self.hit_left = pygame.image.load("Source/%s/die1_%d.png" % (monsterType, 0))
        self.hit_right = pygame.transform.flip(self.hit_left,True,False)

        #pyganim animation
        self.standingAnim_left = pyganim.PygAnimation(self.standing_left)
        self.standingAnim_right = pyganim.PygAnimation(self.standing_right)
        self.walkingAnim_left = pyganim.PygAnimation(self.walking_left)
        self.walkingAnim_right = pyganim.PygAnimation(self.walking_right)
        self.dieAnim_left = pyganim.PygAnimation(self.die_left,False)
        self.dieAnim_right = pyganim.PygAnimation(self.die_right,False)
        self.hitAnim_left = pyganim.PygAnimation([(self.hit_left,1)])
        self.hitAnim_right = pyganim.PygAnimation([(self.hit_right,1)])
        

        self.change_x = 0
        self.change_y = 0
        self.index = 0
        self.image = self.walkingAnim_right.getCurrentFrame()
        #randomly set monster's direction
        direction = random.choice([0,1])
        if direction==0:    self.direction = "R"
        else:   self.direction = "L"
        self.state = "resting"
        self.ani = self.standingAnim_right
        # Set a reference to the image rect
        self.rect = self.ani.getRect()
        self.rect.x = 660
        self.rect.bottom = 500
        self.onGround = False
        #Distance with player
        self.dx_left = 0
        self.dx_right = 0
        self.hp = 500
        self.hitpoint = 30
        self.hurt = False
        self.hurtFinish = True
        self.dying = False
        self.dead = False
    def gravity(self):
        if self.onGround == False:
            self.change_y += 1
            if self.direction == "L": 
                self.ani = self.standingAnim_left
            elif self.direction == "R": 
                self.ani = self.standingAnim_right
        else:
            self.change_y = 0
    def autoMove(self):
        randomState = random.choice([-1,0,1])
        if randomState == 0 and self.direction == "L":
            self.ani = self.standingAnim_left
            self.direction = "L"
            self.change_x = 0
        elif randomState == 0 and self.direction == "R":
            self.ani = self.standingAnim_right
            self.direction = "R"
            self.change_x = 0
        elif randomState == -1:
            self.ani = self.walkingAnim_left
            self.direction = "L"
            self.direction = "L"
            self.change_x = -1
        elif randomState == 1:
            self.ani = self.walkingAnim_right
            self.direction = "R"
            self.direction = "R"
            self.change_x = 1

        self.image = self.ani.getCurrentFrame()
        self.ani.play()
    def update(self, screen):
        if self.hp <= 0:
            if self.direction == "L":   self.ani = self.dieAnim_left
            else:   self.ani = self.dieAnim_right
            self.dead = True
        self.gravity()
        if self.rect.y > constants.SCREEN_HEIGHT:
            self.dead = True
        self.rect.x += self.change_x
        self.rect.y += self.change_y
        self.ani.play()
    def reset(self):
        self.change_x = 0
        self.hurt = False
        if self.direction == "L":
            self.ani = self.standingAnim_left
        else:
            self.ani = self.standingAnim_right
class GreenMushroom(Monster):
    def __init__(self,startTime,monsterType="GreenMushroom"):
        super(GreenMushroom, self).__init__(startTime,monsterType)
        self.hitpoint = 50
class HornMushroom(Monster):
    def __init__(self,startTime,monsterType="HornMushroom"):
        super(HornMushroom, self).__init__(startTime,monsterType)
        self.hitpoint = 80
class Boss1(Monster):
    def __init__(self, startTime,monsterType="Boss1"):
        super(Boss1, self).__init__(startTime,monsterType)
        self.hitpoint = 200 
        self.hp = 1500 
    def __str__(self):
        return "Boss"
class Boss2(Monster):
    def __init__(self, startTime,monsterType="Boss2"):
        super(Boss2, self).__init__(startTime,monsterType)
        self.hitpoint = 200 
        self.hp = 1500 
    def __str__(self):
        return "Boss"
                    

class Fireball(pygame.sprite.Sprite):
    def __init__(self, ani, player):
        super(Fireball, self).__init__()
        self.ani = ani
        self.player = player
        self.rect = self.ani.getRect()
        self.rect.x = copy.deepcopy(player.rect.x)
        self.rect.y = copy.deepcopy(player.rect.y)
        self.player.skillAttacking = True
        self.change_x = 0
        if self.player.direction == "L":
            self.change_x = -10
        elif self.player.direction == "R":
            self.change_x = 10
    def update(self):
        self.rect.x += self.change_x
class Portal(pygame.sprite.Sprite):
    def __init__(self,x,y):
        self.images = []
        for i in range(8):
            image = pygame.image.load("Source/portal/pv_%d.png" %i)
            self.images.append((image,0.1))
        self.ani = pyganim.PygAnimation(self.images)
        self.rect = self.ani.getRect()
        self.rect.x = x
        self.rect.y = y
        self.ani.play()